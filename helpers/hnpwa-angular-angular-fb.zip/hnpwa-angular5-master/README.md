# HNPWA Angular 5.0

Watch the [Angular 5 Service Worker screencast](https://angularfirebase.com/lessons/hnpwa-angular-5-progressive-web-app-service-worker-tutorial/). 

A realtime Hacker News Progressive Web App using: 

- Angular 5.0 
- @angular/service-worker 
- AngularFire2
- Lighthouse: 100 PWA  | ~90 Performance

It's real: [Live Demo](https://hnpwa-cbf63.firebaseapp.com/)

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.6.0-rc.0.
