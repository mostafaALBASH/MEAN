# Simple PWA example 

Online demo can be found on https://marcushellberg.github.io/alternative-news

## Running locally

Serve folder with your server of choice. For instance `npm install -g serve`.

